ПОЛНЫЙ ОТЧЕТ О ТЕСТИРОВАНИИ МОДЕЛЕЙ
===========================================

Этот ZIP-архив содержит все результаты тестирования моделей:

📁 ФАЙЛЫ ОТЧЕТА:
├── models_super_detailed_report.csv    - Супер детальный CSV со всеми метриками
└── roc_curves/                       - Папка с ROC кривыми
    ├── roc_curve_model1.png          - ROC кривые для каждой модели
    └── roc_metadata_model1.txt        - Метаданные ROC кривых

📊 ОПИСАНИЕ CSV ФАЙЛА:
• models_super_detailed_report.csv - содержит ВСЕ метрики в одной строке
  Включает: Rank, Model, Accuracy, F1_Macro, Avg_ROC_AUC,
  ROC AUC по классам, Precision/Recall/F1 по классам,
  Confusion matrix данные, Support, Error Status

📈 ROC КРИВЫЕ:
Каждая модель имеет:
• PNG файл с ROC кривой
• TXT файл с метаданными и ROC AUC по классам

⏰ Время создания: 2026-02-14 10:26:08
🏆 Победитель: resnet18_baseline_20260214_032948_best.pth
